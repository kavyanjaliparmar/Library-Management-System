package com.library.management.model;

public enum Role {
    ROLE_ADMIN,
    ROLE_STUDENT
}
