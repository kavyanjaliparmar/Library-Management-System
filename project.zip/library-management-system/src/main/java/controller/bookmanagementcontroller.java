package controller;

import javafx.collections.*;
import javafx.fxml.FXML;
import javafx.scene.control.*;

public class BookManagementController {

    @FXML private TextField searchField;
    @FXML private TableView<Book> bookTable;
    @FXML private TableColumn<Book, Integer> idCol;
    @FXML private TableColumn<Book, String> titleCol;
    @FXML private TableColumn<Book, String> authorCol;
    @FXML private TableColumn<Book, String> publisherCol;
    @FXML private TableColumn<Book, Integer> yearCol;

    private ObservableList<Book> bookList = FXCollections.observableArrayList();

    @FXML
    public void initialize() {
        idCol.setCellValueFactory(cellData -> cellData.getValue().idProperty().asObject());
        titleCol.setCellValueFactory(cellData -> cellData.getValue().titleProperty());
        authorCol.setCellValueFactory(cellData -> cellData.getValue().authorProperty());
        publisherCol.setCellValueFactory(cellData -> cellData.getValue().publisherProperty());
        yearCol.setCellValueFactory(cellData -> cellData.getValue().yearProperty().asObject());

        // Sample data
        bookList.addAll(
            new Book(1, "The Great Gatsby", "F. Scott Fitzgerald", "Scribner", 1925),
            new Book(2, "1984", "George Orwell", "Secker & Warburg", 1949)
        );

        bookTable.setItems(bookList);
    }

    @FXML
    private void handleAddBook() {
        // Open Add Book dialog or new screen (to implement)
        System.out.println("Add Book clicked");
    }
}