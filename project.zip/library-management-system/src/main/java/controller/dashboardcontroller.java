package controller;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

public class DashboardController {

    @FXML
    private StackPane contentArea;

    @FXML
    private void showHome() throws Exception {
        loadView("HomeView.fxml");
    }

    @FXML
    private void showBooks() throws Exception {
        loadView("BookManagement.fxml");
    }

    @FXML
    private void showIssueReturn() throws Exception {
        loadView("IssueReturn.fxml");
    }

    @FXML
    private void showReports() throws Exception {
        loadView("Reports.fxml");
    }

    @FXML
    private void handleLogout() {
        try {
            // Go back to login
            Stage stage = (Stage) contentArea.getScene().getWindow();
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/Login.fxml"));
            stage.setScene(new javafx.scene.Scene(loader.load()));
            stage.setTitle("Library Management System - Login");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void loadView(String fxmlFile) throws Exception {
        Node view = FXMLLoader.load(getClass().getResource("/fxml/" + fxmlFile));
        contentArea.getChildren().setAll(view);
    }

    @FXML
    public void initialize() {
        // Load home by default
        try {
            showHome();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}