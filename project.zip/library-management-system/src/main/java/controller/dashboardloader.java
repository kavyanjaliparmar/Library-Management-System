package controller;

import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.stage.Window;

public class DashboardLoader {
    public static void loadDashboard(Window currentWindow) throws Exception {
        FXMLLoader loader = new FXMLLoader(DashboardLoader.class.getResource("/fxml/Dashboard.fxml"));
        Scene scene = new Scene(loader.load());
        scene.getStylesheets().add(DashboardLoader.class.getResource("/css/style.css").toExternalForm());
        Stage stage = (Stage) currentWindow;
        stage.setScene(scene);
        stage.setTitle("Library Management System - Dashboard");
        stage.show();
    }
}